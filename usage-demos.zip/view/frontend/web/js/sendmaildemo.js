define(['jquery', 'domReady!'], function ($) {
    'use strict';

    return function () {
        const url = "https://magento2.test/rest/V1/cb/send";
        $('.button_demo').click(() => {
            let data = JSON.stringify({
                "sendTo": {
                    "email": "sendto@demoemail.com"
                },
                "sender": {
                    "email": "sender@demoemail.com",
                    "name": "Sender Name"
                },
                "templateVars": {
                    "test1": "Test Var",
                    "test2": "Test Var 2"
                },
                "subject": "Custom Subject",
                "areaCode": 'frontend',
                "storeId": null,
                "cc": [
                    "emailcc@demoemail.com",
                    "emailcc2@demoemail.com"
                ],
                "bcc": [
                    "emailbcc@demoemail.com",
                    "emailbcc2@demoemail.com"
                ],
                "replyTo": 'replyto@demoemail.com',
                "template": null
            });
            let settings = {
                "async": true,
                "crossDomain": true,
                "url": url,
                "method": "POST",
                "timeout": 0,
                "headers": {
                    "Content-Type": "application/json",
                },
                "data": data
            };

            $.ajax(settings).done(function (response) {
                console.log(response);
                console.log(response.success);
                console.log(response.error);
            });
        });

        $('.button_demo_two').click(() => {
            let data = {
                "sendTo": {
                    "email": "sendto@demoemail.com"
                },
                "sender": {
                    "email": "sender@demoemail.com",
                    "name": "Sender Name"
                },
                "templateVars": {
                    "test1": "Test Var",
                    "test2": "Test Var 2"
                },
                "subject": "Custom Subject",
                "areaCode": 'frontend',
                "storeId": null,
                "cc": [
                    "emailcc@demoemail.com",
                    "emailcc2@demoemail.com"
                ],
                "bcc": [
                    "emailbcc@demoemail.com",
                    "emailbcc2@demoemail.com"
                ],
                "replyTo": 'replyto@demoemail.com',
                "template": null
            };
            const settingsFirstEmail = {
                "async": true,
                "crossDomain": true,
                "url": url,
                "method": "POST",
                "timeout": 0,
                "headers": {
                    "Content-Type": "application/json",
                },
                "data": JSON.stringify(data)
            };
            data.sendTo.email = 'newemailreceiver@demo.com';
            data.bcc = null;
            data.cc = null;
            const settingsSecondEmail = {
                "async": true,
                "crossDomain": true,
                "url": url,
                "method": "POST",
                "timeout": 0,
                "headers": {
                    "Content-Type": "application/json",
                },
                "data": JSON.stringify(data)
            };
            $.when($.ajax(settingsFirstEmail), $.ajax(settingsSecondEmail))
                .then(emailSent, emailFail);
        });

        /**
         * This will be triggered after sendind the 2 emails and only if
         * both are successfull
         *
         * @param resFirstEmail
         * @param resSecondEmail
         */
        function emailSent(resFirstEmail, resSecondEmail) {
            console.log(resFirstEmail);
            console.log(resFirstEmail[0].success);

            console.log(resSecondEmail);
            console.log(resSecondEmail[0].success);
            //even if request is successfull, some errors may come here
            //make sure you are listening to the value in res.success and res.error
            //in order to handle errors properly
        }

        /**
         * This will be triggered after sendind the 2 emails and only if
         * any of them fails
         *
         * @param resFirstEmail
         * @param resSecondEmail
         */
        function emailFail(resFirstEmail, resSecondEmail) {
            console.log(resFirstEmail);
            console.log(resSecondEmail);
        }
    }
});
