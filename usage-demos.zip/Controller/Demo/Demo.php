<?php

namespace CodeBaby\Email\Controller\Demo;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;

class Demo extends \Magento\Framework\App\Action\Action implements ActionInterface, HttpGetActionInterface, HttpPostActionInterface
{

    private PageFactory $resultPageFactory;

    public function __construct(Context $context, PageFactory $resultPageFactory)
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        /** @var \Magento\Framework\View\Result\Page $page */
        $page = $this->resultPageFactory->create();
        $page->getConfig()->getTitle()->prepend((__('Demo Email')));
        return $page;
    }
}
