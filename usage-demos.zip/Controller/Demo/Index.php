<?php

namespace CodeBaby\Email\Controller\Demo;

use CodeBaby\Email\Model\Service\MailService;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class Index implements ActionInterface, HttpGetActionInterface, HttpPostActionInterface
{
    private MailService $mailService;
    private JsonFactory $jsonFactory;

    public function __construct(MailService $mailService, JsonFactory $jsonFactory)
    {
        $this->mailService = $mailService;
        $this->jsonFactory = $jsonFactory;
    }

    public function execute()
    {
        $sendTo = [ 'email' => 'sendto@demoemail.com' ];
        $sender = [
            "email" => "sender@demoemail.com",
            "name" => "Sender Name"
        ];
        $templateVars = [
            "test1" => "Test",
            "test2" => "Test 2"
        ];
        $subject = "Custom Subject";
        $areaCode = "frontend";
        $storeId = '0';
        $cc = [
            "emailcc@demoemail.com",
            "emailcc2@demoemail.com"
        ];
        $bcc = [
            "emailbcc@demoemail.com",
            "emailbcc2@demoemail.com"
        ];
        $replyTo = 'replyto@demoemail.com';
        $template = null;

        $result = $this->mailService->handle(
            $sendTo,
            $sender,
            $templateVars,
            $subject,
            $areaCode,
            $storeId,
            $cc,
            $bcc,
            $replyTo,
            $template
        );
        $json = $this->jsonFactory->create();
        $json->setData($result);
        return $json;
    }
}
